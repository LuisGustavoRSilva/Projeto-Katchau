import Pessoa from "./Pessoa";

export default class Cliente extends Pessoa{
    aniversario!:Date;
}