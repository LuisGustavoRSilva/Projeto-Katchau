export default class Produto{
    id!:number;
    nome!:string;
    descricao!:string;
    preco!:number;
    foto1!:string;
    foto2!:string;
    foto3!:string;
}