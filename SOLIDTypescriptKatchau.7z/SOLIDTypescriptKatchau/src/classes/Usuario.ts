export default class Usuario{
    id!:Number;
    nomeusuario!: string;
    senha!: string;
    fotousuario!: string;
    criadoem!:Date;
    atualizadoem!:Date;
}
